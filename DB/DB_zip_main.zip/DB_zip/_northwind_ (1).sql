-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 06, 2023 at 11:44 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `northwind`
--
CREATE DATABASE IF NOT EXISTS `northwind` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `northwind`;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `ProductID` int(3) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key column',
  `ProductName` varchar(50) DEFAULT NULL,
  `SupplierID` int(10) DEFAULT NULL,
  `CategoryID` int(10) DEFAULT NULL,
  `QuantityPerUnit` int(10) NOT NULL,
  `UnitPrice` int(50) DEFAULT NULL,
  `UnitsInStock` int(50) NOT NULL,
  `UnitsOnOrder` int(20) NOT NULL,
  `ReorderLevel` int(30) NOT NULL,
  `Discontinued` tinyint(1) NOT NULL,
  PRIMARY KEY (`ProductID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`ProductID`, `ProductName`, `SupplierID`, `CategoryID`, `QuantityPerUnit`, `UnitPrice`, `UnitsInStock`, `UnitsOnOrder`, `ReorderLevel`, `Discontinued`) VALUES
(1, 'bottle', 1001, 5001, 20, 50000, 20, 5, 3, 0),
(2, 'chess', 1002, 5002, 25, 2000, 55, 12, 4, 0),
(3, 'book', 1003, 5003, 14, 10000, 12, 14, 1, 1),
(4, 'phone', 1004, 5004, 56, 660000, 20, 65, 4, 1),
(5, '', 0, 0, 45, 0, 40, 32, 45, 1),
(6, 'Penbox', 1006, 5006, 78, 100, 42, 123, 45, 1),
(7, 'notepad', 1007, 5007, 45, 30, 42, 75, 78, 1),
(8, 'keyboard', 1008, 5008, 87, 350, 20, 46, 1, 0),
(9, 'Jacket', 1009, 5009, 21, 1000, 42, 25, 100, 1),
(10, 'Moniter', 1010, 5010, 45, 3450, 50, 142, 5, 0),
(11, 'Headphone', 1011, 5011, 45, 5000, 56, 10, 4, 1),
(12, 'Gulanjamun', 1012, 5012, 50, 250, 500, 86, 89, 1),
(13, 'Fan', 1013, 5013, 65, 10000, 45, 12, 7, 0),
(14, 'Savlon Cream', 1014, 5014, 125, 50, 875, 12, 12, 0),
(15, 'Lifeboy', 1015, 5012, 12, 70, 45, 14, 44, 1),
(16, 'Mobile Cover', 1016, 5016, 42, 100, 980, 124, 4, 0),
(17, NULL, NULL, NULL, 424, NULL, 1, 1, 1, 1),
(18, 'Wires', NULL, NULL, 535, 1000, 45, 4, 4, 0),
(19, 'AC', 1019, 5019, 22, 50050, 42, 54, 14, 0),
(20, 'Bike', NULL, 5020, 54, 90000, 20, 12, 7, 1),
(21, 'watch', NULL, NULL, 424, NULL, 424, 43, 10, 1),
(22, NULL, NULL, NULL, 0, NULL, 0, 0, 0, 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
