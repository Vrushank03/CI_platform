-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 06, 2023 at 11:44 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sales`
--
CREATE DATABASE IF NOT EXISTS `sales` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `sales`;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `customer_id` int(10) NOT NULL,
  `cust_name` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `grade` varchar(50) NOT NULL,
  `salesman_id` int(10) NOT NULL,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `salesman_id` (`salesman_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `cust_name`, `city`, `grade`, `salesman_id`) VALUES
(101, 'Jinish', 'Jamnagar', 'A', 1),
(102, 'Smit', 'Lmbdi', 'B', 2),
(103, 'Yug', 'Rajkot', 'B', 3),
(104, 'Krunal', 'Rajkot', 'A', 4),
(105, 'Usma', 'Pune', 'A', 5),
(106, 'Kinjal', 'Vadodara', 'C', 6),
(107, 'Hashang', 'Surat', 'A', 7),
(108, 'Bina', 'Surat', 'D', 8),
(109, 'Mitanshu', 'Surat', 'B', 9),
(110, 'Sharvil', 'Vadodara', 'D', 10),
(111, 'Janvi', 'Rajkot', 'B', 11),
(112, 'Rakhi', 'Bhavnagar', 'B', 12),
(113, 'Dhavait', 'Ahmedabad', 'C', 13),
(114, 'Jayesh', 'Ahmedabad', 'A', 14),
(115, 'Mita', 'Vadodara', 'B', 15),
(116, 'Raman', 'Rajkot', 'C', 16),
(117, 'Rita', 'Surat', 'D', 17),
(118, 'Shayam', 'Bharuch', 'B', 18),
(119, 'Ram', 'Vadodara', 'A', 19),
(200, 'Paul', 'Vadodara', 'A', 20);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `ord_no` int(10) NOT NULL,
  `purch_amt` int(10) NOT NULL,
  `ord_date` date NOT NULL,
  `customer_id` int(20) NOT NULL,
  `salesman_id` int(10) NOT NULL,
  UNIQUE KEY `customer_id` (`customer_id`,`salesman_id`),
  KEY `salesman_id` (`salesman_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`ord_no`, `purch_amt`, `ord_date`, `customer_id`, `salesman_id`) VALUES
(1001, 2500, '2023-02-01', 101, 1),
(1002, 5000, '2023-02-02', 102, 2),
(1003, 2500, '2023-01-01', 103, 3),
(1004, 5000, '2020-02-15', 104, 4),
(1005, 456, '2020-02-15', 105, 5),
(1006, 765, '2022-12-06', 106, 6),
(1007, 1240, '2023-01-05', 107, 7),
(1008, 5000, '2023-02-06', 108, 8),
(1009, 3000, '2019-01-12', 109, 9),
(1010, 3500, '2020-11-03', 110, 10),
(1011, 4500, '2018-12-08', 111, 11),
(1012, 7500, '2016-01-02', 112, 12),
(1013, 4500, '2019-02-03', 113, 13),
(1014, 6000, '2019-05-04', 114, 14),
(1015, 7000, '2018-04-21', 115, 15),
(1016, 6500, '2020-05-30', 116, 16),
(1017, 8500, '2020-05-30', 117, 17),
(1018, 6352, '2020-09-23', 118, 18),
(1019, 3600, '2023-10-25', 119, 19),
(1020, 5500, '2023-10-25', 200, 20);

-- --------------------------------------------------------

--
-- Table structure for table `salesman`
--

CREATE TABLE IF NOT EXISTS `salesman` (
  `salesman_id` int(10) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `city` varchar(50) NOT NULL,
  `commission` int(10) NOT NULL,
  PRIMARY KEY (`salesman_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salesman`
--

INSERT INTO `salesman` (`salesman_id`, `name`, `city`, `commission`) VALUES
(1, 'Paul', 'Vadodara', 10),
(2, 'Ram', 'Vadodara', 10),
(3, 'Shayam', 'Bharuch', 9),
(4, 'Rita', 'Surat', 8),
(5, 'Raman', 'Rajkot', 3),
(6, 'Mita', 'Vadodara', 5),
(7, 'Jayesh', 'Ahmedabad', 6),
(8, 'Dhaivat', 'Ahmedabad', 11),
(9, 'Rakhi', 'Bhavnagar', 5),
(10, 'Janvi', 'Rajkot', 8),
(11, 'Sharvil', 'Vadodara', 8),
(12, 'Mitanshu', 'Surat', 3),
(13, 'Bina', 'Surat', 4),
(14, 'Harshang', 'Surat', 5),
(15, 'Kinjal', 'Vadodara', 9),
(16, 'Usma', 'Pune', 9),
(17, 'krunal', 'Rajkot', 9),
(18, 'Yug', 'Rajkot', 7),
(19, 'Smit', 'Limbi', 10),
(20, 'Jinish', 'Jamnagar', 11);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customer`
--
ALTER TABLE `customer`
  ADD CONSTRAINT `salesman_id` FOREIGN KEY (`salesman_id`) REFERENCES `salesman` (`salesman_id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `customer_id` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`),
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`salesman_id`) REFERENCES `salesman` (`salesman_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
